<template>
    <h3> Hello </h3>

</template>

<script>
    import Raphael from 'raphael/raphael';
    global.Raphael = Raphael;
    import JQuery from 'jquery';
    import Vue from 'vue';
    import DonutChart from 'vue-morris'
    export default {
        name: "WorkingTimes"
    }
</script>

<style scoped>

</style>