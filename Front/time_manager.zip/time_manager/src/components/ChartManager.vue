<template>
    <h3> Hello </h3>
</template>

<script>
    export default {
        name: "ChartManager"
    }
</script>

<style scoped>

</style>